$(function(){
	var isReady = false;
	var WX = (function() {
		this.message = function(spanid, msgshow) {
			$("span#"+spanid).html(msgshow);
		};
		this.setready = function() {
			$("button[data]").each(function(ni,mo) {
				$(mo).removeClass('btn-default')
					.addClass('btn-success')
					.click(function() {
						$.ajax({
							url: 'exec?'+Math.random(),
							type: 'post',
							dataType: 'json',
							data: {
								command: $(mo).attr("data")
							},
							success: function(rp) {
								if (rp.code != 0) {
									return alert(rp.info);
								}
							}
						});
					});
			});
			isReady = true;
		};
		return this;
	})();
	$.ajax({
		url: 'boot?'+Math.random(),
		type: 'post',
		dataType: 'json',
		data: {},
		success: function(rp) {
			if (rp.code != 0) {
				return alert(rp.info);
			}
			var oform = document.forms["appConfig"];
			oform.appid.value = rp.data.appid;
			oform.seckey.value = rp.data.seckey;
			oform.callback.value = rp.data.backurl;
			var msg = "需要通过授权获取到访问令牌才能进行后面的接口操作！";
			if (rp.data.token == 'ON') {
				WX.setready();
				msg = "当前的AppID: " + rp.data.appid;
				msg += " | 已经通过授权获得访问令牌";
				$('#AuthorizeRQ').removeClass("btn-default").addClass("btn-danger");
			} else if (rp.data.appid != "") {
				msg = "当前的AppID: " + rp.data.appid;
				$('#AuthorizeRQ').removeClass("btn-default").addClass("btn-success")
			}
			if (rp.data.forward != "") {
				$('#AuthorizeRQ').click(function() { window.location.href = rp.data.forward; });
			}
			WX.message("TK", msg);
		}
	});
	$(document.forms["appConfig"]).submit(function(){
		if (document.forms["appConfig"].appid.value.length != 32 && document.forms["appConfig"].appid.value.length != 16) {
			alert("AppID 格式不对，只能是32位或16位字符串！");
			document.forms["appConfig"].appid.focus();
			return false;
		}
		if (document.forms["appConfig"].seckey.value.length != 32) {
			alert("AppSecret 格式不对，只能是32位字符串！");
			document.forms["appConfig"].seckey.focus();
			return false;
		}
		$.ajax({
			url: "init"+"?"+Math.random(),
			type: "post",
			dataType: "json",
			data: $(document.forms["appConfig"]).serialize(),
			success: function(rp) {
				if (rp.code != 0) {
					return alert(rp.info);
				}
				$('#AuthorizeRQ').removeClass("btn-default")
					.addClass("btn-success")
					.click(function() {
						window.location.href = rp.data.forward;
					});
				WX.message("TK", "当前使用的AppID值为："+rp.data.appid);
			}
		});
		return false;
	});
});