package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.Map;
import java.util.HashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import cn.yiban.open.Authorize;

import util.Stream;


public class Initialization extends HttpServlet
{
	public final int    SUCCESS_CODE_T = 0;
	public final String STRING_BLANK_T = "";
	
	
	/**
	 * 设置 appid 及 appsecret 值
	 *
	 * 使用 session保存appid与appsecret值
	 *
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		HttpSession session = request.getSession();
		
		String appid   = request.getParameter("appid");
		String seckey  = request.getParameter("seckey");
		String backurl = request.getParameter("callback");
		
		if (seckey != "********************************")
		{
			session.setAttribute("seckey",  seckey);
		}
		session.setAttribute("appid",   appid);
		session.setAttribute("backurl", backurl);
		
		// 设置appid后，清掉旧的token记录如果有的话
		session.removeAttribute("token");
		session.removeAttribute("userid");
		session.removeAttribute("expires");
		
		Authorize au = new Authorize(appid, seckey);
		
		Map<String, String> data = new HashMap<String, String>();
		data.put("appid",  appid);
		// data.put("seckey", seckey);
		data.put("forward", au.forwardurl(backurl, "QUERY", Authorize.DISPLAY_TAG_T.WEB));
		
		response.setContentType("text/plain; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(Stream.out(Stream.SUCCESS, Stream.BLANK, data));
	}
}