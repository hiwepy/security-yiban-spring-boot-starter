package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.Map;
import java.util.HashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import cn.yiban.open.Authorize;

import util.Stream;


public class Bootstrap extends HttpServlet
{
	/**
	 * 设置 appid 及 appsecret 值
	 *
	 * 使用 session保存appid与appsecret值
	 *
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		HttpSession session = request.getSession();
		
		String appid   = (String) session.getAttribute("appid");
		String seckey  = (String) session.getAttribute("seckey");
		String backurl = (String) session.getAttribute("backurl");
		String token   = (String) session.getAttribute("token");
		String forward = new String();
		
		if (appid == null)
		{
			appid = "";
		}
		if (seckey != null && !seckey.isEmpty())
		{
			seckey = "********************************";
			Authorize au = new Authorize(appid, seckey);
			forward = au.forwardurl(backurl, "RELOAD", Authorize.DISPLAY_TAG_T.WEB);
		}
		else
		{
			seckey = "";
		}
		if (backurl == null)
		{
			backurl = "";
		}
		token = (token == null || token.isEmpty()) ? "OFF" : "ON";
		
		Map<String, String> data = new HashMap<String, String>();
		data.put("appid",   appid);
		data.put("seckey",  seckey);
		data.put("backurl", backurl);
		data.put("token",	token);
		data.put("forward", forward);
		
		response.setContentType("text/plain; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(Stream.out(Stream.SUCCESS, Stream.BLANK, data));
	}
}