package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.Map;
import java.util.HashMap;

import cn.yiban.open.Authorize;
import cn.yiban.util.HTTPSimple;
import cn.yiban.open.common.User;
import cn.yiban.open.common.Friend;

import util.Stream;


public class Execution extends HttpServlet
{
	
	/**
	 * 设置 appid 及 appsecret 值
	 *
	 * 使用 session保存appid与appsecret值
	 *
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		HttpSession session = request.getSession();
		
		String appid   = (String) session.getAttribute("appid");
		String seckey  = (String) session.getAttribute("seckey");
		String token   = (String) session.getAttribute("token");
		
		String command = request.getParameter("command");
		String returnText = "";
		
		switch (command)
		{
			case "ai":
			{
				Authorize au = new Authorize(appid, seckey);
				returnText = au.getManInstance(token).query();
				break;
			}
			case "ar":
			{
				Authorize au = new Authorize(appid, seckey);
				returnText = au.getManInstance(token).revoke();
				break;
			}
			case "um":
			{
				User u = new User(token);
				returnText = u.me();
				break;
			}
			case "ur":
			{
				User u = new User(token);
				returnText = u.realme();
				break;
			}
			case "uo":
			{
				User u = new User(token);
				returnText = u.other(1);
				break;
			}
			case "fl":
			{
				Friend f = new Friend(token);
				returnText = f.list(1, 10);
				break;
			}
			case "fc":
			{
				Friend f = new Friend(token);
				returnText = f.check(1);
				break;
			}
		}
		response.setContentType("text/plain; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(Stream.out(Stream.SUCCESS, Stream.BLANK, returnText));
	}
	
}