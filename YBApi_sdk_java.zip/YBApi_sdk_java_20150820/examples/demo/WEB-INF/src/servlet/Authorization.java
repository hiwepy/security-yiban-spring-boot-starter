package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.Map;
import java.util.HashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import cn.yiban.open.Authorize;

import util.Stream;


public class Authorization extends HttpServlet
{
	public final int    SUCCESS_CODE_T = 0;
	public final String STRING_BLANK_T = "";
	

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		String code = request.getParameter("code");
		
		if (code == null || code.isEmpty())
		{
			response.sendRedirect("index.html");
		}
		HttpSession session = request.getSession();
		
		String appid   = (String) session.getAttribute("appid");
		String seckey  = (String) session.getAttribute("seckey");
		String backurl = (String) session.getAttribute("backurl");
		
		Authorize au = new Authorize(appid, seckey);
		String text = au.querytoken(code, backurl);
		
		if (text == null || text.isEmpty())
		{
			response.sendRedirect("index.html");
		}
		JSONObject json = JSONObject.fromObject(text);
		
		if (json == null)
		{
			response.sendRedirect("index.html");
		}
		
		if (json.has("access_token"))
		{
			if (json.has("userid"))
			{
				session.setAttribute("userid", json.getString("userid"));
			}
			if (json.has("expires"))
			{
				session.setAttribute("expires", json.getString("expires"));
			}
			session.setAttribute("token", json.getString("access_token"));
		}
		else
		{
			
		}
		response.sendRedirect("index.html");
	}
}