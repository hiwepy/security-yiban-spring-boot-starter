package util;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


public class Stream
{
	public static int  SUCCESS = 0;
	public static String BLANK = "";
	
	public static String out(int code, String message, Object data)
	{
		if (data == null)
		{
			data = new Object();
		}
		JSONObject json = new JSONObject();
		json.put("code", Integer.valueOf(code));
		json.put("info", message);
		json.put("data", data);
		return json.toString();
	}
	
}